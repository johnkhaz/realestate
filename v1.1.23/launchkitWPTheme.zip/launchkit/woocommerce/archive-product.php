<?php 
	/**
	 * @author  TommusRhodus
	 * @version 9.9.9
	 */
?>
<?php

$image = get_option( 'shop_background' );

get_header( 'shop' );
?>

<section class="header header-11"><div class="hero-slider"><ul class="slides"><li>

	<?php if(!empty($image)) : ?>
	<div class="background-image-holder">
		<img alt="Background Image" class="background-image" src="<?php echo esc_url( $image ); ?>">
	</div>
	<?php endif; ?>

	<div class="container">
		<div class="row">
			<div class="col-sm-12 text-center">
			
				<?php if ( apply_filters( 'woocommerce_show_page_title', true ) ) : ?>
				
					<h2 class="text-white"><?php woocommerce_page_title(); ?></h2>
				
				<?php endif; ?>
				
				<p class="text-white lead"><?php woocommerce_breadcrumb(); ?></p>
			</div>
		</div>
	</div>
	
</li></ul></div></section>

	<section class="instructions">
		<div class="container">
			<div class="row">
				<div class="col-sm-12 text-center">
					
					<?php do_action( 'woocommerce_archive_description' ); ?>
					
					<?php
						/**
						 * woocommerce_before_shop_loop hook
						 *
						 * @hooked woocommerce_result_count - 20
						 * @hooked woocommerce_catalog_ordering - 30
						 */
						do_action( 'woocommerce_before_shop_loop' );
					?>
	
				</div>
			</div><!--end of row-->
		</div><!--end of container-->	
	</section>

		<?php if ( have_posts() ) : ?>

			<?php woocommerce_product_loop_start(); ?>

				<?php woocommerce_product_subcategories(); ?>

				<?php while ( have_posts() ) : the_post(); ?>

					<?php wc_get_template_part( 'content', 'product' ); ?>

				<?php endwhile; // end of the loop. ?>

			<?php woocommerce_product_loop_end(); ?>

			<?php
				/**
				 * woocommerce_after_shop_loop hook
				 *
				 * @hooked woocommerce_pagination - 10
				 */
				do_action( 'woocommerce_after_shop_loop' );
			?>

		<?php elseif ( ! woocommerce_product_subcategories( array( 'before' => woocommerce_product_loop_start( false ), 'after' => woocommerce_product_loop_end( false ) ) ) ) : ?>

			<?php wc_get_template( 'loop/no-products-found.php' ); ?>

		<?php endif; ?>

<?php get_footer( 'shop' ); ?>
