<?php 
	/**
	 * @author  TommusRhodus
	 * @version 9.9.9
	 */
?>
<?php
	get_header( 'shop' ); 
	$class = ( is_active_sidebar('shop') ) ? 'col-md-9' : 'col-md-10 col-md-offset-1';
	
	if( has_post_thumbnail() ) :
	
		$url = wp_get_attachment_url( get_post_thumbnail_id( get_the_ID() ) );
		echo ebor_archive_header( get_the_title(), esc_url( $url ), get_the_time( get_option( 'date_format' ) ) );
	
	else :
?>

	<section class="header header-11">
		<div class="hero-slider">
			<ul class="slides">
				<li>
					<div class="container">
						<div class="row">
							<div class="col-sm-12 text-center">
							
								<?php if ( apply_filters( 'woocommerce_show_page_title', true ) ) : ?>
								
									<h2 class="text-white"><?php woocommerce_page_title(); ?></h2>
								
								<?php endif; ?>
								
								<p class="text-white lead"><?php woocommerce_breadcrumb(); ?></p>
							</div>
						</div>
					</div>
				</li>
			</ul>
		</div>
	</section>

<?php endif; ?>

<section class="blog">
	<div class="container">
		<div class="row">
			
			<div class="<?php echo esc_attr( $class ); ?>">
			
				<?php while ( have_posts() ) : the_post(); ?>
		
					<?php wc_get_template_part( 'content', 'single-product' ); ?>
		
				<?php endwhile; // end of the loop. ?>
		
			</div>
		
			<?php
				/**
				 * woocommerce_sidebar hook
				 *
				 * @hooked woocommerce_get_sidebar - 10
				 */
				do_action( 'woocommerce_sidebar' );
			?>
	
		</div><!--end of row-->
	</div><!--end of container-->
</section>

<?php 
	woocommerce_output_related_products(); 
	get_footer( 'shop' ); 