<?php 
	/**
	 * @author  TommusRhodus
	 * @version 9.9.9
	 */
?>
<?php  
	global $wp_query;
	
	if ( $wp_query->max_num_pages <= 1 ) {
		return;
	}
?>

<section class="instructions">
	<div class="container">
		<div class="row">
			<div class="col-sm-12 text-center">
			
				<?php echo ebor_pagination( $wp_query->max_num_pages ); ?>

			</div>
		</div><!--end of row-->
	</div><!--end of container-->	
</section>
