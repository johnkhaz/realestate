<?php 
	/**
	 * @author  TommusRhodus
	 * @version 9.9.9
	 */
?>
<?php global $product, $woocommerce_loop; ?>

<div class="col-md-6">
	<div class="choice">
	
		<?php do_action( 'woocommerce_before_shop_loop_item' ); ?>
	
		<a href="<?php the_permalink(); ?>">
			<?php
				/**
				 * woocommerce_before_shop_loop_item_title hook
				 *
				 * @hooked woocommerce_show_product_loop_sale_flash - 10
				 * @hooked woocommerce_template_loop_product_thumbnail - 10
				 */
				do_action( 'woocommerce_before_shop_loop_item_title' );
			?>
		</a>
		
		<div class="desc">
			<?php 
				the_title( '<h6>', '</h6>' );
				
				/**
				 * woocommerce_after_shop_loop_item_title hook
				 *
				 * @hooked woocommerce_template_loop_rating - 5
				 * @hooked woocommerce_template_loop_price - 10
				 */
				do_action( 'woocommerce_after_shop_loop_item_title' );
				
				echo wpautop( wp_trim_words( get_the_excerpt(), 15 ) );
			?>
			<div class="buttons-holder">
				<?php
					/**
					 * woocommerce_after_shop_loop_item hook
					 *
					 * @hooked woocommerce_template_loop_add_to_cart - 10
					 */
					do_action( 'woocommerce_after_shop_loop_item' ); 
				?>
				<a class="text-link" href="<?php the_permalink(); ?>"><?php esc_html_e( 'View More', 'launchkit' ); ?></a>
			</div>
		</div>
	
	</div>
</div>