===================================================================
June 3rd 2019 - v1.1.23
-------------------------------------------------------------------

* UPDATED: Coding tweaked to meet WP requirments
* FIXED: WPBakery CSS no longer overrides theme when using a child theme

===================================================================
April 22nd 2019 - v1.1.22
-------------------------------------------------------------------

* FIXED: Space at start of theme metabox file
* ADDED: MerlinWP theme setup

===================================================================
January 17th 2019 - v1.1.21
-------------------------------------------------------------------

* UPDATED: Envato Themeforest Check Fixes
* UPDATED: Added One click demo importer support
* ADDED: Basic Gutenberg compatibility
* UPDATED: Coding Standards accross all theme files

===================================================================
April 6th 2018 - v1.1.20
-------------------------------------------------------------------

* FIXED: Broken Instagram feeds due to unannounced API change
  
===================================================================
April 2nd 2018 - v1.1.19
-------------------------------------------------------------------

* FIXED: Broken Twitter Feeds

===================================================================
March 2nd 2018 - v1.1.18
-------------------------------------------------------------------

* FIXED: Set post date in header of single products to display none
* FIXED: Video hero block issue when no contact form was selected
* UPDATED: Visual Composer required version

===================================================================
May 19th 2017 - v1.1.17
-------------------------------------------------------------------

* FIXED: Twitter feeds
* FIXED: Google font string in theme options accepts + now
* UPDATED: Visual composer
* FIXED: Visual composer issues with latest version
* WOOCOMMERCE: 3.0.x integration
* WOOCOMMERCE: Image gallery changed to new WooCommerce zoom gallery
* WOOCOMMERCE: Included template version numbers updated