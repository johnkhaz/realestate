<form class="search" method="get" id="searchform" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<input type="text" id="s2" name="s" placeholder="<?php esc_attr_e( 'Type and hit enter..', 'launchkit' ); ?>" />
</form>