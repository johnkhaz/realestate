<?php 

/**
 * Build theme metaboxes
 * Uses the cmb metaboxes class found in the ebor framework plugin
 * More details here: https://github.com/WebDevStudios/Custom-Metaboxes-and-Fields-for-WordPress
 * 
 * @since 1.0.0
 * @author tommusrhodus
 */
if(!( function_exists( 'ebor_custom_metaboxes' ) )){
	function ebor_custom_metaboxes( $meta_boxes ) {
		
		/**
		 * Setup variables
		 */
		$prefix = '_ebor_';
		$footer_options = ebor_get_footer_options();
		$header_options = ebor_get_header_options();
		
		$footer_overrides['none'] = 'Do Not Override Footer Option On This Page';
		foreach( $footer_options as $key => $value ){
			$footer_overrides[$key] = 'Override Footer: ' . $value; 	
		}
		
		$header_overrides['none'] = 'Do Not Override Header Option On This Page';
		foreach( $header_options as $key => $value ){
			$header_overrides[$key] = 'Override Header: ' . $value; 	
		}
		
		/**
		 * Subtitles
		 */
		$meta_boxes[] = array(
			'id' 			=> 'subtitle_metabox',
			'title'			=> esc_html__( 'The Subtitle', 'launchkit' ),
			'object_types'  => array('portfolio'), // post type
			'context' 		=> 'side',
			'priority' 		=> 'low',
			'show_names' 	=> true, // Show field names on the left
			'fields' => array(
				array(
					'name' => '',
					'desc' => '(Optional) Enter a subtitle for this post / page.',
					'id'   => $prefix . 'the_subtitle',
					'type' => 'text',
				)
			)
		);
		
		/**
		 * Post & Portfolio Header Images
		 */
		$meta_boxes[] = array(
			'id' 			=> 'post_header_metabox',
			'title' 		=> esc_html__( 'Page Overrides', 'launchkit' ),
			'object_types'  => array( 'page', 'team', 'post', 'portfolio' ), // post type
			'context' 		=> 'normal',
			'priority' 		=> 'low',
			'show_names' 	=> true, // Show field names on the left
			'fields' => array(
				array(
					'name'         => esc_html__( 'Override Header?', 'launchkit' ),
					'desc'         => esc_html__( 'Header Layout is set in "appearance" -> "customise". To override this for this page only, use this control.', 'launchkit' ),
					'id'           => $prefix . 'header_override',
					'type'         => 'select',
					'options'      => $header_overrides,
					'std'          => 'none'
				),
				array(
					'name'         => esc_html__( 'Override Footer?', 'launchkit' ),
					'desc'         => esc_html__( 'Footer Layout is set in "appearance" -> "customise". To override this for this page only, use this control.', 'launchkit' ),
					'id'           => $prefix . 'footer_override',
					'type'         => 'select',
					'options'      => $footer_overrides,
					'std'          => 'none'
				),
			)
		);
		
		$meta_boxes[] = array(
			'id' 			=> 'clients_metabox',
			'title'			=> esc_html__( 'Client URL', 'launchkit' ),
			'object_types' 	=> array('client'), // post type
			'context' 		=> 'normal',
			'priority' 		=> 'high',
			'show_names' 	=> true, // Show field names on the left
			'fields' => array(
				array(
					'name' => esc_html__( 'URL for this client (optional)', 'launchkit' ),
					'desc' => esc_html__( "Enter a URL for this client, if left blank, client logo will open into a lightbox.", 'launchkit' ),
					'id'   => $prefix . 'client_url',
					'type' => 'text',
				),
			),
		);
		
		return $meta_boxes;
	}
	add_filter( 'cmb2_meta_boxes', 'ebor_custom_metaboxes' );
}