<?php 

/**
 * Here is all the custom colours for the theme.
 * $handle is a reference to the handle used with wp_enqueue_style()
 */
if (class_exists( 'WPLessPlugin' )){

    $less = WPLessPlugin::getInstance();
	
    $less->setVariables(
    	array(
			'standard-space'      => get_option( 'standard-space', '80' ) . 'px',
			'color-primary'       => get_option( 'color-primary', '#6dc77a' ),
			'color-bg-secondary'  => get_option( 'color-bg-secondary', '#F6F8FA' ),
			'color-body'          => get_option( 'color-body', '#888888' ),
			'color-heading'       => get_option( 'color-heading', '#222222' ),
			'color-bg'            => get_option( 'color-bg', '#FFFFFF' )
    	)
    );
    
}

if(!( function_exists( 'tommusrhodus_body_font_url' ) )){
	function tommusrhodus_body_font_url(){
	
	    $font_url = '';
	    if ( 'off' !== _x( 'on', 'Google font: on or off', 'launchkit' ) ) {
	        $font_url = add_query_arg( 
				'family', 
				urlencode( 
					str_replace( '+', ' ', get_option( 'body_font_url', 'Lato:300,400,700,300italic,400italic|Questrial|Lora:400,700,400italic' ) ) 
				), 
				"//fonts.googleapis.com/css" 
	        );
	    }
	    
	    return $font_url;
	    
	}
}

/**
 * Ebor Load Scripts
 * Properly Enqueues Scripts & Styles for the theme
 * @since version 1.0
 * @author TommusRhodus
 */ 
if(!( function_exists( 'ebor_load_scripts' ) )){
	function ebor_load_scripts() {
		// Get theme data for cache busting
		$theme_data    = wp_get_theme();
		$version       = $theme_data->get( 'Version' );	
		$directory    = trailingslashit(get_template_directory_uri());
		//Enqueue Fonts
		if( $font_url = tommusrhodus_body_font_url() ){
			wp_enqueue_style( 
				'ebor-body-font', 
				$font_url, 
				array(), 
				$version 
			);
		}
			
		//Enqueue Styles
		$extension = ( class_exists( 'WPLessPlugin' ) ) ? '.less' : '.css';
		wp_enqueue_style( 'bootstrap', EBOR_THEME_DIRECTORY . 'style/css/bootstrap.min.css' );
		wp_enqueue_style( 'ebor-fonts', EBOR_THEME_DIRECTORY . 'style/css/fonts.css' );	
		wp_enqueue_style( 'ebor-plugins', EBOR_THEME_DIRECTORY . 'style/css/plugins.css' );	
		wp_enqueue_style( 'ebor-theme-styles', EBOR_THEME_DIRECTORY . 'style/css/theme' . $extension );
		wp_enqueue_style( 'ebor-style', get_stylesheet_uri() );
		
		//Enqueue Scripts
		wp_enqueue_script( 'bootstrap', EBOR_THEME_DIRECTORY . 'style/js/bootstrap.min.js', array('jquery'), false, true  );
		wp_enqueue_script( 'fitvids', EBOR_THEME_DIRECTORY . 'style/js/fitvids.js', array('jquery'), false, true  );
		wp_enqueue_script( 'flexslider', EBOR_THEME_DIRECTORY . 'style/js/flexslider.js', array('jquery'), false, true  );
		wp_enqueue_script( 'placeholders', EBOR_THEME_DIRECTORY . 'style/js/placeholders.js', array('jquery'), false, true  );
		wp_enqueue_script( 'smooth-scroll', EBOR_THEME_DIRECTORY . 'style/js/smooth-scroll.js', array('jquery'), false, true  );
		wp_enqueue_script( 'spectragram', EBOR_THEME_DIRECTORY . 'style/js/spectragram.js', array('jquery'), false, true  );
		wp_enqueue_script( 'twitter-post-fetcher', EBOR_THEME_DIRECTORY . 'style/js/twitter-post-fetcher.js', array('jquery'), false, true  );
		wp_enqueue_script( 'greensocks', EBOR_THEME_DIRECTORY . 'style/js/greensocks.js', array('jquery'), false, true  );
		wp_enqueue_script( 'max-height', EBOR_THEME_DIRECTORY . 'style/js/max-height.js', array('jquery'), false, true  );
		wp_enqueue_script( 'ebor-scripts', EBOR_THEME_DIRECTORY . 'style/js/scripts.js', array('jquery'), false, true  );
		
		//Enqueue Comments
		if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
			wp_enqueue_script( 'comment-reply' );
		}
		
		$custom_styles = '
			.nav-1 .logo {
				margin-top: '. get_option('logo_margin','28') .'px;
				max-height: '. get_option('logo_height','18') .'px;
			}
		';
		wp_add_inline_style( 'ebor-style', $custom_styles );
		
		//Add custom CSS ability
		wp_add_inline_style( 'ebor-style', get_option('custom_css') );
		
		/**
		 * localize script
		 */
		$script_data = array( 
			'access_token'       => get_option( 'instagram_token', '' ),
			'client_id'          => get_option( 'instagram_client', '' )
		);
		wp_localize_script( 'ebor-scripts', 'wp_data', $script_data );
	}
	add_action( 'wp_enqueue_scripts', 'ebor_load_scripts', 110 );
}

/**
 * Ebor Load Admin Scripts
 * Properly Enqueues Scripts & Styles for the theme
 * 
 * @since version 1.0
 * @author TommusRhodus
 */
if(!( function_exists( 'ebor_admin_load_scripts' ) )){
	function ebor_admin_load_scripts(){
		wp_enqueue_style( 'ebor-theme-admin-css', EBOR_THEME_DIRECTORY . 'admin/ebor-theme-admin.css' );
		wp_enqueue_style( 'ebor-fonts', EBOR_THEME_DIRECTORY . 'style/css/fonts.css' );	
		wp_enqueue_script( 'ebor-theme-admin-js', EBOR_THEME_DIRECTORY . 'admin/ebor-theme-admin.js', array('jquery'), false, true  );
	}
	add_action( 'admin_enqueue_scripts', 'ebor_admin_load_scripts', 200 );
}