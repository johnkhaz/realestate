<?php 

if(!( function_exists( 'ebor_cart_icon' ) )){
	function ebor_cart_icon( $items, $args ) {
		if( 'primary' == $args->theme_location ){
			global $woocommerce;
			$items .= '<li class="shopping-cart menu-icon"><a href="'. esc_url( wc_get_cart_url() ) .'"><i class="icon icon-caddie-shopping-streamline"></i></a></li>';
		}
		return $items;
	}
	add_filter( 'wp_nav_menu_items', 'ebor_cart_icon', 20, 2 );
}

remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20 );