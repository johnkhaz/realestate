<?php 

/**
 * Build theme options
 * Uses the Ebor_Options class found in the ebor-framework plugin
 * Panels are WP 4.0+!!!
 * 
 * @since 1.0.0
 * @author tommusrhodus
 */
if( class_exists( 'Ebor_Options' ) ){
	$ebor_options = new Ebor_Options;
	
	/**
	 * Variables
	 */
	$theme = wp_get_theme();
	$theme_name = $theme->get( 'Name' );
	$footer_default = '*copy* *current_year* LaunchKit. By <a href="http://www.tommusrhodus.com">TommusRhodus</a>';
	$footer_layouts = ebor_get_footer_options();
	$header_layouts = ebor_get_header_options();
	
	$social_options = ebor_get_icons();
	$fonts_description = 'Fonts: ' . $theme_name . ' uses Google Fonts, <a href="https://www.google.com/fonts" target="_blank">all of which are viewable here</a>. Unlike some themes, ' . $theme_name . ' does not load all of these fonts into these options, in avoiding this ' . $theme_name . ' can work faster and more reliably.<br /><br />
	
	To customize the fonts on your website use the URL above and the inputs below accordingly. Full details of this process (and the default values) can be found in the theme documentation!';
	
	/**
	 * Default stuff
	 * 
	 * Each of these is a default option that appears in each theme, demo data, favicons and a custom css input
	 * 
	 * @since 1.0.0
	 * @author tommusrhodus
	 */
	$ebor_options->add_panel( $theme_name . ': Demo Data', 5, '');
	$ebor_options->add_panel( $theme_name . ': Styling Settings', 205, 'All of the controls in this section directly relate to the styling page of ' . $theme_name);
	$ebor_options->add_section('demo_data_section', 'Import Demo Data', 10, $theme_name . ': Demo Data', '<strong>Please read this before importing demo data via this control:</strong><br /><br />The demo data this will install includes images from my demo site with <strong>heavy blurring applied</strong> this is due to licensing restrictions. Simply replace these images with your own.<br /><br />Note that this process can take up to 15mins on slower servers, go make a cup of tea. If you havn\'t had a notification in 30mins, use the fallback method outlined in the written documentation.<br /><br />');
	$ebor_options->add_section('favicon_section', 'Favicons', 30, $theme_name . ': Styling Settings');
	$ebor_options->add_section('custom_css_section', 'Custom CSS', 40, $theme_name . ': Styling Settings');
	$ebor_options->add_setting('image', 'custom_favicon', 'Custom Favicon Upload (Use .png)', 'favicon_section', '', 10);
	$ebor_options->add_setting('image', 'mobile_favicon', 'Mobile Favicon Upload (Use .png)', 'favicon_section', '', 15);
	$ebor_options->add_setting('image', '72_favicon', '72x72px Favicon Upload (Use .png)', 'favicon_section', '', 20);
	$ebor_options->add_setting('image', '114_favicon', '114x114px Favicon Upload (Use .png)', 'favicon_section', '', 25);
	$ebor_options->add_setting('image', '144_favicon', '144x144px Favicon Upload (Use .png)', 'favicon_section', '', 30);
	$ebor_options->add_setting('demo_import', 'demo_import', 'Import Demo Data', 'demo_data_section', '', 10);
	$ebor_options->add_setting('textarea', 'custom_css', 'Custom CSS', 'custom_css_section', '', 30);
	
	/**
	 * Panels
	 * 
	 * add_panel($name, $priority, $description)
	 * 
	 * @since 1.0.0
	 * @author tommusrhodus
	 */
	$ebor_options->add_panel( $theme_name . ': Header Settings', 215, 'All of the controls in this section directly relate to the header and logos of ' . $theme_name);
	$ebor_options->add_panel( $theme_name . ': Blog Settings', 225, 'All of the controls in this section directly relate to the control of blog items within ' . $theme_name);
	$ebor_options->add_panel( $theme_name . ': Portfolio Settings', 230, 'All of the controls in this section directly relate to the control of portfolio items within ' . $theme_name);
	$ebor_options->add_panel( $theme_name . ': Team Settings', 235, 'All of the controls in this section directly relate to the control of team items within ' . $theme_name);
	if ( class_exists( 'WooCommerce' ) ) {
		$ebor_options->add_panel( $theme_name . ': Shop Settings', 240, 'All of the controls in this section directly relate to the control of shop items within ' . $theme_name);
	}
	$ebor_options->add_panel( $theme_name . ': Footer Settings', 290, 'All of the controls in this section directly relate to the control of the footer within ' . $theme_name);
	
	/**
	 * Sections
	 * 
	 * add_section($name, $title, $priority, $panel, $description)
	 * 
	 * @since 1.0.0
	 * @author tommusrhodus
	 */
	//Styling
	$ebor_options->add_section('fonts_section', 'Fonts', 5, $theme_name . ': Styling Settings', $fonts_description);
	
	//Portfolio Sections
	$ebor_options->add_section('portfolio_text_section', 'Portfolio Settings', 15, $theme_name . ': Portfolio Settings');
	$ebor_options->add_section('team_text_section', 'Team Settings', 10, $theme_name . ': Team Settings');
	$ebor_options->add_section('blog_text_section', 'Blog Settings', 5, $theme_name . ': Blog Settings');
	
	//Header Settings
	$ebor_options->add_section('logo_settings_section', 'Logo Settings', 10, $theme_name . ': Header Settings');
	$ebor_options->add_section('footer_social_settings_section', 'Footer Icons Settings', 40, $theme_name . ': Footer Settings', '');
	$ebor_options->add_section('header_layout_section', 'Header Layout', 5, $theme_name . ': Header Settings', 'This setting controls the theme header site-wide. If you need to you can override this setting on specific posts and pages from within that posts edit screen.');
	
	//Footer Settings
	$ebor_options->add_section('footer_layout_section', 'Footer Layout', 5, $theme_name . ': Footer Settings', 'This setting controls the theme footer site-wide. If you need to you can override this setting on specific posts and pages from within that posts edit screen.');
	$ebor_options->add_section('subfooter_settings_section', 'Sub-Footer Settings', 30, $theme_name . ': Footer Settings');
	$ebor_options->add_section('footer_social_settings_section', 'Footer Icons Settings', 40, $theme_name . ': Footer Settings', 'These social icons are only shown in certain footer layouts.');

	if ( class_exists( 'WooCommerce' ) ) {
		$ebor_options->add_section('shop_settings', 'WooCommerce Settings', 1, $theme_name . ': Shop Settings');
	}
	
	/**
	 * Settings (The Actual Options)
	 * Repeated settings are stepped using a for() loop and counter
	 * 
	 * add_setting($type, $option, $title, $section, $default, $priority, $select_options)
	 * 
	 * @since 1.0.0
	 * @author tommusrhodus
	 */
	//Fonts
	$ebor_options->add_setting('input', 'body_font', 'Body Font', 'fonts_section', 'Lato', 10);
	$ebor_options->add_setting('textarea', 'body_font_url', 'Body Font URL Parameter', 'fonts_section', 'http://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic|Questrial|Lora:400,700,400italic', 15);
	
	//Colour Options
	$ebor_options->add_setting('color', 'color-bg', 'Light Wrapper Colour', 'colors', '#FFFFFF', 1);
	$ebor_options->add_setting('color', 'color-bg-secondary', 'Dark Wrapper Colour', 'colors', '#F6F8FA', 5);
	$ebor_options->add_setting('color', 'color-primary', 'Highlight Colour', 'colors', '#6dc77a', 10);
	$ebor_options->add_setting('color', 'color-body', 'Body Font Colour', 'colors', '#888888', 15);
	$ebor_options->add_setting('color', 'color-heading', 'Headings Font Colour', 'colors', '#222222', 20);

	//Portfolio options
	$ebor_options->add_setting('input', 'portfolio_title', 'Portfolio Archives: Title', 'portfolio_text_section', 'Our Portfolio', 20);
	$ebor_options->add_setting('image', 'portfolio_background', 'Portfolio Archives: Header Background', 'portfolio_text_section', '', 25);
	
	$ebor_options->add_setting('input', 'blog_title', 'Blog Archives: Title', 'blog_text_section', 'Our Journal', 20);
	$ebor_options->add_setting('image', 'blog_background', 'Blog Archives: Header Background', 'blog_text_section', '', 25);
	
	$ebor_options->add_setting('input', 'team_title', 'Team Archives: Title', 'team_text_section', 'Our Team', 20);
	$ebor_options->add_setting('image', 'team_background', 'Team Archives: Header Background', 'team_text_section', '', 25);
	
	//Logo Options
	$ebor_options->add_setting('image', 'custom_logo', 'Logo', 'logo_settings_section', EBOR_THEME_DIRECTORY . 'style/img/logo-dark.png', 5);
	$ebor_options->add_setting('image', 'custom_logo_light', 'Light Logo', 'logo_settings_section', EBOR_THEME_DIRECTORY . 'style/img/logo-light.png', 10);
	$ebor_options->add_setting('range', 'logo_height', 'Logo Height (18 Default)', 'logo_settings_section', '18', 15, array('min' => '0', 'max' => '120', 'step' => '1'));
	$ebor_options->add_setting('range', 'logo_margin', 'Logo Top Margin (28 Default)', 'logo_settings_section', '28', 15, array('min' => '0', 'max' => '120', 'step' => '1'));

	//WooCommerce
	if ( class_exists( 'WooCommerce' ) ) {
		$ebor_options->add_setting('image', 'shop_background', 'Shop: Header Background', 'shop_settings', '', 20);
	}
	
	//Footer Options
	$ebor_options->add_setting('textarea', 'copyright', 'Copyright Message - Here you can use *copy* to show a copyright symbol, as well as *current_year* to display the current year.' , 'subfooter_settings_section', $footer_default, 20);
	
	//Header Layout Option
	$ebor_options->add_setting('select', 'header_layout', 'Global Header Layout', 'header_layout_section', 'light', 5, $header_layouts);
	$ebor_options->add_setting('input', 'cta_url', 'Call to Action Button URL', 'header_layout_section', '', 10);
	$ebor_options->add_setting('input', 'cta_text', 'Call to Action Button Text', 'header_layout_section', 'Build Yours »', 15);
	
	
	$ebor_options->add_setting('select', 'footer_layout', 'Global Footer Layout', 'footer_layout_section', '4', 5, $footer_layouts);
	$ebor_options->add_setting('textarea', 'call_to_action_footer', 'Call to Action Footer Content', 'footer_layout_section', '<p class="lead">Book today and receive a free Activity Tracker!</p><a class="btn btn-filled" href="#">Book Now</a>', 20);
	$ebor_options->add_setting('image', 'image_social_footer', 'Image Social Footer Background', 'footer_layout_section', '', 10);
	
	//Footer Icons
	for( $i = 1; $i < 5; $i++ ){
		$ebor_options->add_setting('select', 'footer_social_icon_' . $i, 'Footer Social Icon ' . $i, 'footer_social_settings_section', 'none', 20 + $i + $i, $social_options);
		$ebor_options->add_setting('input', 'footer_social_url_' . $i, 'Footer Social URL ' . $i, 'footer_social_settings_section', '', 21 + $i + $i);
	}
	
	/**
	 * Instagram API Stuff
	 */
	$ebor_options->add_section('instagram_api_section', $theme_name . ': Instagram Settings', 340, false, '<code>IMPORTANT NOTE:</code> This is the Instagram setup section for the theme, it requires an Access Token and Client ID.<br /><br />Due to how Instagram have set their API you have to register as a developer with Instagram for this to work.<br /><br />For setup details, <a href="https://tommusrhodus.ticksy.com/article/7566" target="_blank">please read this</a>');
	$ebor_options->add_setting('input', 'instagram_token', 'Instagram Access Token', 'instagram_api_section', '', 5);
	$ebor_options->add_setting('input', 'instagram_client', 'Instagram Client ID', 'instagram_api_section', '', 10);
}