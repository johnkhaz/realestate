<?php 

if(!( function_exists( 'ebor_framework_updates_notification' ) )){
  	function ebor_framework_updates_notification(){
  		
  		global $current_user;
  		$user_id = $current_user->ID;
  		
  		/* Check that the user hasn't already clicked to ignore the message */
  		if ( ! get_user_meta( $user_id, 'launchkit_notice' ) ) {
  			
			echo '
				<div class="notice notice-warning is-dismissible">
					<div class="content">
						<h3>Launchkit 1.1.21 Has Made Some Big Changes - PLEASE READ</h3>
				        <p>Launchkit was first released in 2015, since then we\'ve improved certain aspects of our themes to bring them inline with modern standards, this update of Launchkit is part of that.</p>
				        <p>If you\'re a new user to aunchkit, ignore this and continue setting up your theme with the documentation. Existing users:</p>
				        <ol>
				        	<li>Please follow the link below to update Visual Composer, Ebor Framework, and install "WP LESS".</li>
				        	<li>If your site is showing shortcodes instead of rendered content after step 1, please visit "appearance => themes" switch to another theme on this screen. After activating another theme, re-activate aunchkit, aunchkit will then run through its initial setup functions and resolve this for you.</li>
				        </ol>
				        <p><a class="button button-primary" href="'. esc_url( admin_url( 'themes.php?page=tgmpa-install-plugins' ) ) .'">Install & Update Plugins</a> | <strong><a href="'. esc_url( admin_url('?ebor_nag_ignore=0') ) .'">Dismiss Notice</a></strong></p>
			        </div>
			    </div>
		    ';
	    
  		}
  	    
  	}
  	add_action( 'admin_notices', 'ebor_framework_updates_notification' );
}
if(!( function_exists( 'ebor_nag_ignore' ) )){
	function ebor_nag_ignore() {
		global $current_user;
	    $user_id = $current_user->ID;
	    
	    /* If user clicks to ignore the notice, add that to their user meta */
	    if ( isset($_GET['ebor_nag_ignore']) && '0' == $_GET['ebor_nag_ignore'] ) {
	    	add_user_meta($user_id, 'launchkit_notice', 'true', true);
		}
	}
	add_action( 'admin_init', 'ebor_nag_ignore' );
}

if(!( function_exists( 'ebor_allowed_tags' ) )){ 
	function ebor_allowed_tags(){
		return array(
		    'a' 	=> array(
		        'href' 	=> array(),
		        'title' => array(),
		        'class' => array()
		    ),
		    'br' 	=> array(),
		    'em' 	=> array(),
		    'strong' => array(),
		    'p' => array(
		    	'class' => array()
		    ),
		);	
	}
}

if(!( function_exists( 'ebor_get_header_options' ) )){
	function ebor_get_header_options(){
		$options = array(
			'blank' 	=> 'No Header or Nav',
			'light' 	=> 'Light Header',
			'dark' 		=> 'Dark Header',
			'icons' 	=> 'Icon Header',
		);
		return $options;	
	}
}

if(!( function_exists( 'ebor_get_footer_options' ) )){
	function ebor_get_footer_options(){
		$options = array(
			'blank' 	=> 'No Footer',
			'1' 		=> 'Slim Social Footer',
			'2' 		=> 'Center Menu Footer',
			'3' 		=> 'Column Menu Footer',
			'4' 		=> 'Image Social Footer',
			'5' 		=> 'Call to Action Footer',
			'6' 		=> 'Columns Menu Footer',
			'widgets' 	=> 'Widgets Footer'
		);
		return $options;	
	}
}

/**
 * ebor_get_footer_layout
 * 
 * Use to conditionally check the page footer meta layout against the theme option for the same
 * In short, this function can override the global footer option on a post by post basis
 * Call within get_footer() for this to override the global footer choice
 * 
 * @since 1.0.0
 * @author tommusrhodus
 */
if(!( function_exists( 'ebor_get_footer_layout' ) )){
	function ebor_get_footer_layout(){
		global $post;
		
		if(!( isset($post->ID) )) {
			return get_option( 'footer_layout', '4' );
		}
			
		$footer = get_post_meta($post->ID, '_ebor_footer_override', 1);
		if( '' == $footer || false == $footer || 'none' == $footer ){
			$footer = get_option( 'footer_layout', '4' );
		}
		return $footer;	
	}
}

/**
 * ebor_get_header_layout
 * 
 * Use to conditionally check the page header meta layout against the theme option for the same
 * In short, this function can override the global header option on a post by post basis
 * Call within get_header() for this to override the global header choice
 * 
 * @since 1.0.0
 * @author tommusrhodus
 */
if(!( function_exists( 'ebor_get_header_layout' ) )){
	function ebor_get_header_layout(){
		global $post;
		
		if(!( isset($post->ID) )) {
			return get_option( 'header_layout', 'light' );
		}
		
		$header = get_post_meta( $post->ID, '_ebor_header_override', 1 );
		if( '' == $header || false == $header || 'none' == $header ){
			$header = get_option( 'header_layout', 'light' );
		}
		
		return $header;	
	}
}

/**
 * Collect and display post subtitle
 */
if(!( function_exists( 'ebor_the_subtitle' ) )){
	function ebor_the_subtitle( $before = false, $after = false ){
		
		global $post;
		$subtitle = get_post_meta( $post->ID, '_ebor_the_subtitle', true );
		
		if( isset($post) && $subtitle  ){
			echo wp_kses_post( $before . $subtitle . $after );
		} else {
			return false;
		}
		
	}
}

if(!( function_exists( 'ebor_archive_header' ) )){
	function ebor_archive_header( $title = false, $image = false, $subtitle = false ){
		
		$overlay = ($image) ? 'overlay' : '';
		$output = '<section class="header header-11 '. $overlay .'"><div class="hero-slider"><ul class="slides"><li>
		
			<div class="background-image-holder">
				<img alt="Background Image" class="background-image" src="'. esc_url( $image ) .'">
			</div>
		
			<div class="container">
				<div class="row">
					<div class="col-sm-12 text-center">
						<h2 class="text-white">'. $title .'</h2>
						<p class="text-white lead">'. $subtitle .'</p>
					</div>
				</div>
			</div>
			
		</li></ul></div></section>';
		
		return $output;
	}
}

/**
 * HEX to RGB Converter
 *
 * Converts a HEX input to an RGB array.
 * @param $hex - the inputted HEX code, can be full or shorthand, #ffffff or #fff
 * @since 1.0.0
 * @return string
 * @author tommusrhodus
 */
if(!( function_exists( 'ebor_hex2rgb' ) )){
	function ebor_hex2rgb( $hex ) {
	   $hex = str_replace( "#", "", $hex );
	
	   if(strlen($hex) == 3) {
	      $r = hexdec(substr($hex,0,1).substr($hex,0,1));
	      $g = hexdec(substr($hex,1,1).substr($hex,1,1));
	      $b = hexdec(substr($hex,2,1).substr($hex,2,1));
	   } else {
	      $r = hexdec(substr($hex,0,2));
	      $g = hexdec(substr($hex,2,2));
	      $b = hexdec(substr($hex,4,2));
	   }
	   $rgb = array($r, $g, $b);
	   return implode(",", $rgb); // returns the rgb values separated by commas
	   return $rgb; // returns an array with the rgb values
	}
}

/**
 * Portfolio Unlimited
 * Uses pre_get_posts to provide unlimited portfolio posts when viewing the /portfolio/ archive
 * @since 1.0.0
 */
if(!(function_exists( 'ebor_portfolio_unlimited' ))){
	function ebor_portfolio_unlimited( $query ) {
	    if ( 
	    	is_post_type_archive( 'portfolio' ) && !( is_admin() ) && $query->is_main_query() ||
	    	is_tax( 'portfolio_category' ) && !( is_admin() ) && $query->is_main_query()
	    ) {
	        $query->set( 'posts_per_page', '-1' );
	    }    
	    return;
	}
	add_action( 'pre_get_posts', 'ebor_portfolio_unlimited' );
}

/**
 * Init theme options
 * Certain theme options need to be written to the database as soon as the theme is installed.
 * This is either for the enqueues in ebor-framework, or to override the default image sizes in WooCommerce.
 * Either way this function is only called when the theme is first activated, de-activating and re-activating the theme will result in these options returning to defaults.
 * 
 * @since 1.0.0
 * @author tommusrhodus
 */
if(!( function_exists( 'ebor_init_theme_options' ) )){
	/**
	 * Hook in on activation
	 */
	global $pagenow;	

	/**
	 * Define image sizes
	 */
	function ebor_init_theme_options() {

		//Set all options to zero before initialising options for this theme
		$existing_options = get_option( 'ebor_framework_options' );
		if( is_array($existing_options) ){
			foreach ($existing_options as $key => $value) {
				$existing_options[$key] = '0';
			}
			update_option( 'ebor_framework_options', $existing_options );
		}	

		//Ebor Framework
		$framework_args = array(
			'portfolio_post_type'   	=> '1',
			'team_post_type'        	=> '1',
			'client_post_type'      	=> '1',
			'testimonial_post_type' 	=> '1',
			'mega_menu'             	=> '0',
			'aq_resizer'            	=> '0',
			'page_builder'          	=> '0',
			'likes'                 	=> '0',
			'options'               	=> '1',
			'metaboxes'             	=> '1',
			'pivot_shortcodes'      	=> '1',
			'launchkit_widgets'     	=> '1',
			'launchkit_vc_shortcodes'   => '1'
		);
		update_option('ebor_framework_options', $framework_args);
	}
	
	/**
	 * Only call this action when we first activate the theme.
	 */
	if ( 
		is_admin() && isset( $_GET['activated'] ) && $pagenow == 'themes.php' ||
		is_admin() && isset( $_GET['theme'] ) && $pagenow == 'customize.php'
	){
		add_action( 'init', 'ebor_init_theme_options', 1 );
	}
}

/**
 * Register the required plugins for this theme.
 * 
 * @since 1.0.0
 * @author tommusrhodus
 */
if(!( function_exists( 'ebor_register_required_plugins' ) )){
	function ebor_register_required_plugins() {
		$plugins = array(
			array(
			    'name'      => esc_html__( 'WP Less', 'launchkit' ),
			    'slug'      => 'wp-less',
			    'required'  => true,
			    'version' 	=> '1.0.0'
			),
			array(
			    'name'      => 'Contact Form 7',
			    'slug'      => 'contact-form-7',
			    'required'  => false,
			    'version' 	=> '3.7.2'
			),
			array(
				'name'     				=> 'Ebor Framework',
				'slug'     				=> 'Ebor-Framework-master',
				'source'   				=> 'https://github.com/tommusrhodus/ebor-framework/archive/master.zip',
				'required' 				=> true,
				'version' 				=> '1.0.0',
				'external_url' 			=> 'https://github.com/tommusrhodus/ebor-framework/archive/master.zip',
			),
			array(
				'name'     				=> 'Visual Composer',
				'slug'     				=> 'js_composer',
				'source'   				=> 'http://www.madeinebor.com/plugin-downloads/js_composer-latest.zip',
				'required' 				=> true,
				'external_url' 			=> 'http://www.madeinebor.com/plugin-downloads/js_composer-latest.zip',
				'version' 				=> '5.4.5',
			),
			array(
			    'name'      => 'WooCommerce',
			    'slug'      => 'woocommerce',
			    'required'  => false,
			    'version' 	=> '2.0.0'
			),
			array(
			    'name'      => esc_html__( 'One Click Demo Import', 'launchkit' ),
			    'slug'      => 'one-click-demo-import',
			    'required'  => false,
			    'version' 	=> '1.0.0'
			),
		);

		tgmpa( $plugins );
	}
	add_action( 'tgmpa_register', 'ebor_register_required_plugins' );
}

if(!( function_exists( 'ebor_pagination' ) )){
	function ebor_pagination( $pages = '', $range = 2 ){
		$showitems = ($range * 2)+1;
		
		global $paged;
		if(empty($paged)) $paged = 1;
		
		if($pages == ''){
			global $wp_query;
			$pages = $wp_query->max_num_pages;
				if(!$pages) {
					$pages = 1;
				}
		}
		
		$output = '';
		
		if(1 != $pages){
			
		if(1 != $pages){
			$output .= "<div class='row'><div class='col-sm-12 text-center'><ul class='pagination'>";
			if($paged > 2 && $paged > $range+1 && $showitems < $pages) $output .= "<li><a href='".get_pagenum_link(1)."'><span aria-hidden='true'>«</span><span class='sr-only'>Previous</span></a></li> ";
			
			for ($i=1; $i <= $pages; $i++){
				if (1 != $pages &&( !($i >= $paged+$range+1 || $i <= $paged-$range-1) || $pages <= $showitems )){
					$output .= ($paged == $i)? "<li class='active'><a href='".get_pagenum_link( $i )."'>".$i."</a></li> ":"<li><a href='".get_pagenum_link( $i )."'>".$i."</a></li> ";
				}
			}
		
			if ($paged < $pages-1 &&  $paged+$range-1 < $pages && $showitems < $pages) $output .= "<li><a href='".get_pagenum_link( $pages )."'><span aria-hidden='true'>»</span><span class='sr-only'>Next</span></a></li> ";
			$output.= "</ul></div></div>";
		}
		
		}
		
		return $output;
	}
}

if(!( function_exists( 'ebor_portfolio_filters' ) )){
	function ebor_portfolio_filters( $cats ){
		
		$output = '<div class="row"><div class="col-sm-12"><ul class="filters"><li data-filter="all" class="active">'. esc_html__( 'All', 'launchkit' ) .'</li>';
		if(is_array($cats)){
			foreach($cats as $cat){
				$output .= '<li data-filter="'. esc_attr( $cat->slug ) .'">'. $cat->name .'</li>';
			}
		}
		$output .= '</ul></div></div>';
		
		return $output;	
	}
}

/**
 * Add additional styling options to TinyMCE
 * 
 * @since 1.0.0
 * @author tommusrhodus
 */
if(!( function_exists( 'ebor_mce_buttons_2' ) )){
	function ebor_mce_buttons_2( $buttons ) {
	    array_unshift( $buttons, 'styleselect' );
	    return $buttons;
	}
	add_filter( 'mce_buttons_2', 'ebor_mce_buttons_2' );
}

/**
 * Add additional styling options to TinyMCE
 * 
 * @since 1.0.0
 * @author tommusrhodus
 */
if(!( function_exists( 'ebor_mce_before_init' ) )){
	function ebor_mce_before_init( $settings ) {
	    $style_formats = array(
	    	array(
	    		'title' 		=> 'Lead P',
	    		'selector' 		=> 'p',
	    		'classes' 		=> 'lead',
	    	),
	    	array(
	    		'title' 		=> 'Button',
	    		'selector' 		=> 'a',
	    		'classes' 		=> 'btn',
	    	),
	    	array(
	    		'title' 		=> 'White Button',
	    		'selector' 		=> 'a',
	    		'classes' 		=> 'btn btn-white',
	    	),
	    	array(
	    		'title' 		=> 'Filled Button',
	    		'selector' 		=> 'a',
	    		'classes' 		=> 'btn btn-filled',
	    	),
	    	array(
	    		'title' 		=> 'Huge Button',
	    		'selector' 		=> 'a',
	    		'classes' 		=> 'btn btn-filled super-action',
	    	),
	    );
	    $settings['style_formats'] = json_encode( $style_formats );
	    return $settings;
	}
	add_filter( 'tiny_mce_before_init', 'ebor_mce_before_init' );
}

if(!( function_exists( 'ebor_get_icons' ) )){
	function ebor_get_icons(){
		$icons = array("none" => "none","icon-amazon" => "amazon","icon-app-store" => "app-store","icon-apple" => "apple","icon-armchair-chair-streamline" => "armchair-chair-streamline","icon-arrow-streamline-target" => "arrow-streamline-target","icon-backpack-streamline-trekking" => "backpack-streamline-trekking","icon-bag-shopping-streamline" => "bag-shopping-streamline","icon-bag" => "bag","icon-barbecue-eat-food-streamline" => "barbecue-eat-food-streamline","icon-barista-coffee-espresso-streamline" => "barista-coffee-espresso-streamline","icon-behance" => "behance","icon-bicycle-vintage" => "bicycle-vintage","icon-bicycle" => "bicycle","icon-blip" => "blip","icon-bomb-bug" => "bomb-bug","icon-book-dowload-streamline" => "book-dowload-streamline","icon-book-read-streamline" => "book-read-streamline","icon-browser-empty" => "browser-empty","icon-browser-full" => "browser-full","icon-browser-streamline-window" => "browser-streamline-window","icon-brush-paint-streamline" => "brush-paint-streamline","icon-bubble-1" => "bubble-1","icon-bubble-2" => "bubble-2","icon-bubble-3" => "bubble-3","icon-bubble-comment-streamline-talk" => "bubble-comment-streamline-talk","icon-bubble-love-streamline-talk" => "bubble-love-streamline-talk","icon-caddie-shop-shopping-streamline" => "caddie-shop-shopping-streamline","icon-caddie-shopping-streamline" => "caddie-shopping-streamline","icon-camera-photo-polaroid-streamline" => "camera-photo-polaroid-streamline","icon-camera-photo-streamline" => "camera-photo-streamline","icon-camera-streamline-video" => "camera-streamline-video","icon-camera" => "camera","icon-chaplin-hat-movie-streamline" => "chaplin-hat-movie-streamline","icon-chef-food-restaurant-streamline" => "chef-food-restaurant-streamline","icon-clap-board" => "clap-board","icon-clipboard" => "clipboard","icon-clock-streamline-time" => "clock-streamline-time","icon-clock" => "clock","icon-cloud" => "cloud","icon-cloudy" => "cloudy","icon-cocktail-mojito-streamline" => "cocktail-mojito-streamline","icon-coffee-streamline" => "coffee-streamline","icon-computer-imac-2" => "computer-imac-2","icon-computer-imac" => "computer-imac","icon-computer-macintosh-vintage" => "computer-macintosh-vintage","icon-computer-network-streamline" => "computer-network-streamline","icon-computer-streamline" => "computer-streamline","icon-cook-pan-pot-streamline" => "cook-pan-pot-streamline","icon-crop-streamline" => "crop-streamline","icon-crown-king-streamline" => "crown-king-streamline","icon-danger-death-delete-destroy-skull-stream" => "danger-death-delete-destroy-skull-stream","icon-dashboard-speed-streamline" => "dashboard-speed-streamline","icon-database-streamline" => "database-streamline","icon-delete-garbage-streamline" => "delete-garbage-streamline","icon-design-graphic-tablet-streamline-tablet" => "design-graphic-tablet-streamline-tablet","icon-design-pencil-rule-streamline" => "design-pencil-rule-streamline","icon-diving-leisure-sea-sport-streamline" => "diving-leisure-sea-sport-streamline","icon-dribbble" => "dribbble","icon-drug-medecine-streamline-syringue" => "drug-medecine-streamline-syringue","icon-earth-globe-streamline" => "earth-globe-streamline","icon-eat-food-fork-knife-streamline" => "eat-food-fork-knife-streamline","icon-eat-food-hotdog-streamline" => "eat-food-hotdog-streamline","icon-edit-modify-streamline" => "edit-modify-streamline","icon-email-mail-streamline" => "email-mail-streamline","icon-envellope-mail-streamline" => "envellope-mail-streamline","icon-envelope" => "envelope","icon-eye-dropper-streamline" => "eye-dropper-streamline","icon-facebook" => "facebook","icon-factory-lift-streamline-warehouse" => "factory-lift-streamline-warehouse","icon-file-ai" => "file-ai","icon-file-jpg" => "file-jpg","icon-file-png" => "file-png","icon-file-psd" => "file-psd","icon-file-text" => "file-text","icon-first-aid-medecine-shield-streamline" => "first-aid-medecine-shield-streamline","icon-food-ice-cream-streamline" => "food-ice-cream-streamline","icon-frame-picture-streamline" => "frame-picture-streamline","icon-google" => "google","icon-graph" => "graph","icon-grid-lines-streamline" => "grid-lines-streamline","icon-handle-streamline-vector" => "handle-streamline-vector","icon-happy-smiley-streamline" => "happy-smiley-streamline","icon-headset-sound-streamline" => "headset-sound-streamline","icon-heart" => "heart","icon-hierarchy-2" => "hierarchy-2","icon-hierarchy" => "hierarchy","icon-home-house-streamline" => "home-house-streamline","icon-ibook-laptop" => "ibook-laptop","icon-imac" => "imac","icon-ink-pen-streamline" => "ink-pen-streamline","icon-ipad-streamline" => "ipad-streamline","icon-ipad" => "ipad","icon-iphone-streamline" => "iphone-streamline","icon-iphone" => "iphone","icon-ipod-mini-music-streamline" => "ipod-mini-music-streamline","icon-ipod-music-streamline" => "ipod-music-streamline","icon-ipod-streamline" => "ipod-streamline","icon-japan-streamline-tea" => "japan-streamline-tea","icon-keyboard" => "keyboard","icon-laptop-macbook-streamline" => "laptop-macbook-streamline","icon-laptop" => "laptop","icon-like-love-streamline" => "like-love-streamline","icon-line" => "line","icon-link-streamline" => "link-streamline","icon-linkedin" => "linkedin","icon-list-thumbnails" => "list-thumbnails","icon-list" => "list","icon-lock-locker-streamline" => "lock-locker-streamline","icon-lock" => "lock","icon-locker-streamline-unlock" => "locker-streamline-unlock","icon-macintosh" => "macintosh","icon-magic-magic-wand-streamline" => "magic-magic-wand-streamline","icon-magnet-streamline" => "magnet-streamline","icon-magnifier" => "magnifier","icon-man-people-streamline-user" => "man-people-streamline-user","icon-map-pin-streamline" => "map-pin-streamline","icon-map-pin" => "map-pin","icon-map-streamline-user" => "map-streamline-user","icon-map" => "map","icon-micro-record-streamline" => "micro-record-streamline","icon-mobileme" => "mobileme","icon-monocle-mustache-streamline" => "monocle-mustache-streamline","icon-moon" => "moon","icon-mouse" => "mouse","icon-music-note-streamline" => "music-note-streamline","icon-music-speaker-streamline" => "music-speaker-streamline","icon-notebook-streamline" => "notebook-streamline","icon-paint-bucket-streamline" => "paint-bucket-streamline","icon-painting-pallet-streamline" => "painting-pallet-streamline","icon-painting-roll-streamline" => "painting-roll-streamline","icon-path" => "path","icon-paypal" => "paypal","icon-pen-streamline-1" => "pen-streamline-1","icon-pen-streamline-2" => "pen-streamline-2","icon-pen-streamline-3" => "pen-streamline-3","icon-pen-streamline" => "pen-streamline","icon-pencil-ruler" => "pencil-ruler","icon-pencil" => "pencil","icon-photo-pictures-streamline" => "photo-pictures-streamline","icon-picture-streamline-1" => "picture-streamline-1","icon-picture-streamline" => "picture-streamline","icon-picture" => "picture","icon-rain" => "rain","icon-receipt-shopping-streamline" => "receipt-shopping-streamline","icon-remote-control-streamline" => "remote-control-streamline","icon-ribbon" => "ribbon","icon-settings-streamline-1" => "settings-streamline-1","icon-settings-streamline-2" => "settings-streamline-2","icon-settings-streamline" => "settings-streamline","icon-shoe" => "shoe","icon-shoes-snickers-streamline" => "shoes-snickers-streamline","icon-speaker-off" => "speaker-off","icon-speaker" => "speaker","icon-speech-streamline-talk-user" => "speech-streamline-talk-user","icon-spotify" => "spotify","icon-squarespace" => "squarespace","icon-stamp-streamline" => "stamp-streamline","icon-streamline-suitcase-travel" => "streamline-suitcase-travel","icon-streamline-sync" => "streamline-sync","icon-streamline-umbrella-weather" => "streamline-umbrella-weather","icon-sun" => "sun","icon-tape" => "tape","icon-target" => "target","icon-tumblr" => "tumblr","icon-twitter" => "twitter","icon-unlock" => "unlock","icon-vimeo" => "vimeo","icon-youtube-alt" => "youtube-alt", ' fa fa-adjust' => ' fa fa-adjust', ' fa fa-adn' => ' fa fa-adn', ' fa fa-align-center' => ' fa fa-align-center', ' fa fa-align-justify' => ' fa fa-align-justify', ' fa fa-align-left' => ' fa fa-align-left', ' fa fa-align-right' => ' fa fa-align-right', ' fa fa-ambulance' => ' fa fa-ambulance', ' fa fa-anchor' => ' fa fa-anchor', ' fa fa-android' => ' fa fa-android', ' fa fa-angellist' => ' fa fa-angellist', ' fa fa-angle-double-down' => ' fa fa-angle-double-down', ' fa fa-angle-double-left' => ' fa fa-angle-double-left', ' fa fa-angle-double-right' => ' fa fa-angle-double-right', ' fa fa-angle-double-up' => ' fa fa-angle-double-up', ' fa fa-angle-down' => ' fa fa-angle-down', ' fa fa-angle-left' => ' fa fa-angle-left', ' fa fa-angle-right' => ' fa fa-angle-right', ' fa fa-angle-up' => ' fa fa-angle-up', ' fa fa-apple' => ' fa fa-apple', ' fa fa-archive' => ' fa fa-archive', ' fa fa-area-chart' => ' fa fa-area-chart', ' fa fa-arrow-circle-down' => ' fa fa-arrow-circle-down', ' fa fa-arrow-circle-left' => ' fa fa-arrow-circle-left', ' fa fa-arrow-circle-o-down' => ' fa fa-arrow-circle-o-down', ' fa fa-arrow-circle-o-left' => ' fa fa-arrow-circle-o-left', ' fa fa-arrow-circle-o-right' => ' fa fa-arrow-circle-o-right', ' fa fa-arrow-circle-o-up' => ' fa fa-arrow-circle-o-up', ' fa fa-arrow-circle-right' => ' fa fa-arrow-circle-right', ' fa fa-arrow-circle-up' => ' fa fa-arrow-circle-up', ' fa fa-arrow-down' => ' fa fa-arrow-down', ' fa fa-arrow-left' => ' fa fa-arrow-left', ' fa fa-arrow-right' => ' fa fa-arrow-right', ' fa fa-arrow-up' => ' fa fa-arrow-up', ' fa fa-arrows' => ' fa fa-arrows', ' fa fa-arrows-alt' => ' fa fa-arrows-alt', ' fa fa-arrows-h' => ' fa fa-arrows-h', ' fa fa-arrows-v' => ' fa fa-arrows-v', ' fa fa-asterisk' => ' fa fa-asterisk', ' fa fa-at' => ' fa fa-at', ' fa fa-backward' => ' fa fa-backward', ' fa fa-ban' => ' fa fa-ban', ' fa fa-bar-chart' => ' fa fa-bar-chart', ' fa fa-barcode' => ' fa fa-barcode', ' fa fa-bars' => ' fa fa-bars', ' fa fa-bed' => ' fa fa-bed', ' fa fa-beer' => ' fa fa-beer', ' fa fa-behance' => ' fa fa-behance', ' fa fa-behance-square' => ' fa fa-behance-square', ' fa fa-bell' => ' fa fa-bell', ' fa fa-bell-o' => ' fa fa-bell-o', ' fa fa-bell-slash' => ' fa fa-bell-slash', ' fa fa-bell-slash-o' => ' fa fa-bell-slash-o', ' fa fa-bicycle' => ' fa fa-bicycle', ' fa fa-binoculars' => ' fa fa-binoculars', ' fa fa-birthday-cake' => ' fa fa-birthday-cake', ' fa fa-bitbucket' => ' fa fa-bitbucket', ' fa fa-bitbucket-square' => ' fa fa-bitbucket-square', ' fa fa-bold' => ' fa fa-bold', ' fa fa-bolt' => ' fa fa-bolt', ' fa fa-bomb' => ' fa fa-bomb', ' fa fa-book' => ' fa fa-book', ' fa fa-bookmark' => ' fa fa-bookmark', ' fa fa-bookmark-o' => ' fa fa-bookmark-o', ' fa fa-briefcase' => ' fa fa-briefcase', ' fa fa-btc' => ' fa fa-btc', ' fa fa-bug' => ' fa fa-bug', ' fa fa-building' => ' fa fa-building', ' fa fa-building-o' => ' fa fa-building-o', ' fa fa-bullhorn' => ' fa fa-bullhorn', ' fa fa-bullseye' => ' fa fa-bullseye', ' fa fa-bus' => ' fa fa-bus', ' fa fa-buysellads' => ' fa fa-buysellads', ' fa fa-calculator' => ' fa fa-calculator', ' fa fa-calendar' => ' fa fa-calendar', ' fa fa-calendar-o' => ' fa fa-calendar-o', ' fa fa-camera' => ' fa fa-camera', ' fa fa-camera-retro' => ' fa fa-camera-retro', ' fa fa-car' => ' fa fa-car', ' fa fa-caret-down' => ' fa fa-caret-down', ' fa fa-caret-left' => ' fa fa-caret-left', ' fa fa-caret-right' => ' fa fa-caret-right', ' fa fa-caret-square-o-down' => ' fa fa-caret-square-o-down', ' fa fa-caret-square-o-left' => ' fa fa-caret-square-o-left', ' fa fa-caret-square-o-right' => ' fa fa-caret-square-o-right', ' fa fa-caret-square-o-up' => ' fa fa-caret-square-o-up', ' fa fa-caret-up' => ' fa fa-caret-up', ' fa fa-cart-arrow-down' => ' fa fa-cart-arrow-down', ' fa fa-cart-plus' => ' fa fa-cart-plus', ' fa fa-cc' => ' fa fa-cc', ' fa fa-cc-amex' => ' fa fa-cc-amex', ' fa fa-cc-discover' => ' fa fa-cc-discover', ' fa fa-cc-mastercard' => ' fa fa-cc-mastercard', ' fa fa-cc-paypal' => ' fa fa-cc-paypal', ' fa fa-cc-stripe' => ' fa fa-cc-stripe', ' fa fa-cc-visa' => ' fa fa-cc-visa', ' fa fa-certificate' => ' fa fa-certificate', ' fa fa-chain-broken' => ' fa fa-chain-broken', ' fa fa-check' => ' fa fa-check', ' fa fa-check-circle' => ' fa fa-check-circle', ' fa fa-check-circle-o' => ' fa fa-check-circle-o', ' fa fa-check-square' => ' fa fa-check-square', ' fa fa-check-square-o' => ' fa fa-check-square-o', ' fa fa-chevron-circle-down' => ' fa fa-chevron-circle-down', ' fa fa-chevron-circle-left' => ' fa fa-chevron-circle-left', ' fa fa-chevron-circle-right' => ' fa fa-chevron-circle-right', ' fa fa-chevron-circle-up' => ' fa fa-chevron-circle-up', ' fa fa-chevron-down' => ' fa fa-chevron-down', ' fa fa-chevron-left' => ' fa fa-chevron-left', ' fa fa-chevron-right' => ' fa fa-chevron-right', ' fa fa-chevron-up' => ' fa fa-chevron-up', ' fa fa-child' => ' fa fa-child', ' fa fa-circle' => ' fa fa-circle', ' fa fa-circle-o' => ' fa fa-circle-o', ' fa fa-circle-o-notch' => ' fa fa-circle-o-notch', ' fa fa-circle-thin' => ' fa fa-circle-thin', ' fa fa-clipboard' => ' fa fa-clipboard', ' fa fa-clock-o' => ' fa fa-clock-o', ' fa fa-cloud' => ' fa fa-cloud', ' fa fa-cloud-download' => ' fa fa-cloud-download', ' fa fa-cloud-upload' => ' fa fa-cloud-upload', ' fa fa-code' => ' fa fa-code', ' fa fa-code-fork' => ' fa fa-code-fork', ' fa fa-codepen' => ' fa fa-codepen', ' fa fa-coffee' => ' fa fa-coffee', ' fa fa-cog' => ' fa fa-cog', ' fa fa-cogs' => ' fa fa-cogs', ' fa fa-columns' => ' fa fa-columns', ' fa fa-comment' => ' fa fa-comment', ' fa fa-comment-o' => ' fa fa-comment-o', ' fa fa-comments' => ' fa fa-comments', ' fa fa-comments-o' => ' fa fa-comments-o', ' fa fa-compass' => ' fa fa-compass', ' fa fa-compress' => ' fa fa-compress', ' fa fa-connectdevelop' => ' fa fa-connectdevelop', ' fa fa-copyright' => ' fa fa-copyright', ' fa fa-credit-card' => ' fa fa-credit-card', ' fa fa-crop' => ' fa fa-crop', ' fa fa-crosshairs' => ' fa fa-crosshairs', ' fa fa-css3' => ' fa fa-css3', ' fa fa-cube' => ' fa fa-cube', ' fa fa-cubes' => ' fa fa-cubes', ' fa fa-cutlery' => ' fa fa-cutlery', ' fa fa-dashcube' => ' fa fa-dashcube', ' fa fa-database' => ' fa fa-database', ' fa fa-delicious' => ' fa fa-delicious', ' fa fa-desktop' => ' fa fa-desktop', ' fa fa-deviantart' => ' fa fa-deviantart', ' fa fa-diamond' => ' fa fa-diamond', ' fa fa-digg' => ' fa fa-digg', ' fa fa-dot-circle-o' => ' fa fa-dot-circle-o', ' fa fa-download' => ' fa fa-download', ' fa fa-dribbble' => ' fa fa-dribbble', ' fa fa-dropbox' => ' fa fa-dropbox', ' fa fa-drupal' => ' fa fa-drupal', ' fa fa-eject' => ' fa fa-eject', ' fa fa-ellipsis-h' => ' fa fa-ellipsis-h', ' fa fa-ellipsis-v' => ' fa fa-ellipsis-v', ' fa fa-empire' => ' fa fa-empire', ' fa fa-envelope' => ' fa fa-envelope', ' fa fa-envelope-o' => ' fa fa-envelope-o', ' fa fa-envelope-square' => ' fa fa-envelope-square', ' fa fa-eraser' => ' fa fa-eraser', ' fa fa-eur' => ' fa fa-eur', ' fa fa-exchange' => ' fa fa-exchange', ' fa fa-exclamation' => ' fa fa-exclamation', ' fa fa-exclamation-circle' => ' fa fa-exclamation-circle', ' fa fa-exclamation-triangle' => ' fa fa-exclamation-triangle', ' fa fa-expand' => ' fa fa-expand', ' fa fa-external-link' => ' fa fa-external-link', ' fa fa-external-link-square' => ' fa fa-external-link-square', ' fa fa-eye' => ' fa fa-eye', ' fa fa-eye-slash' => ' fa fa-eye-slash', ' fa fa-eyedropper' => ' fa fa-eyedropper', ' fa fa-facebook' => ' fa fa-facebook', ' fa fa-facebook-official' => ' fa fa-facebook-official', ' fa fa-facebook-square' => ' fa fa-facebook-square', ' fa fa-fast-backward' => ' fa fa-fast-backward', ' fa fa-fast-forward' => ' fa fa-fast-forward', ' fa fa-fax' => ' fa fa-fax', ' fa fa-female' => ' fa fa-female', ' fa fa-fighter-jet' => ' fa fa-fighter-jet', ' fa fa-file' => ' fa fa-file', ' fa fa-file-archive-o' => ' fa fa-file-archive-o', ' fa fa-file-audio-o' => ' fa fa-file-audio-o', ' fa fa-file-code-o' => ' fa fa-file-code-o', ' fa fa-file-excel-o' => ' fa fa-file-excel-o', ' fa fa-file-image-o' => ' fa fa-file-image-o', ' fa fa-file-o' => ' fa fa-file-o', ' fa fa-file-pdf-o' => ' fa fa-file-pdf-o', ' fa fa-file-powerpoint-o' => ' fa fa-file-powerpoint-o', ' fa fa-file-text' => ' fa fa-file-text', ' fa fa-file-text-o' => ' fa fa-file-text-o', ' fa fa-file-video-o' => ' fa fa-file-video-o', ' fa fa-file-word-o' => ' fa fa-file-word-o', ' fa fa-files-o' => ' fa fa-files-o', ' fa fa-film' => ' fa fa-film', ' fa fa-filter' => ' fa fa-filter', ' fa fa-fire' => ' fa fa-fire', ' fa fa-fire-extinguisher' => ' fa fa-fire-extinguisher', ' fa fa-flag' => ' fa fa-flag', ' fa fa-flag-checkered' => ' fa fa-flag-checkered', ' fa fa-flag-o' => ' fa fa-flag-o', ' fa fa-flask' => ' fa fa-flask', ' fa fa-flickr' => ' fa fa-flickr', ' fa fa-floppy-o' => ' fa fa-floppy-o', ' fa fa-folder' => ' fa fa-folder', ' fa fa-folder-o' => ' fa fa-folder-o', ' fa fa-folder-open' => ' fa fa-folder-open', ' fa fa-folder-open-o' => ' fa fa-folder-open-o', ' fa fa-font' => ' fa fa-font', ' fa fa-forumbee' => ' fa fa-forumbee', ' fa fa-forward' => ' fa fa-forward', ' fa fa-foursquare' => ' fa fa-foursquare', ' fa fa-frown-o' => ' fa fa-frown-o', ' fa fa-futbol-o' => ' fa fa-futbol-o', ' fa fa-gamepad' => ' fa fa-gamepad', ' fa fa-gavel' => ' fa fa-gavel', ' fa fa-gbp' => ' fa fa-gbp', ' fa fa-gift' => ' fa fa-gift', ' fa fa-git' => ' fa fa-git', ' fa fa-git-square' => ' fa fa-git-square', ' fa fa-github' => ' fa fa-github', ' fa fa-github-alt' => ' fa fa-github-alt', ' fa fa-github-square' => ' fa fa-github-square', ' fa fa-glass' => ' fa fa-glass', ' fa fa-globe' => ' fa fa-globe', ' fa fa-google' => ' fa fa-google', ' fa fa-google-plus' => ' fa fa-google-plus', ' fa fa-google-plus-square' => ' fa fa-google-plus-square', ' fa fa-google-wallet' => ' fa fa-google-wallet', ' fa fa-graduation-cap' => ' fa fa-graduation-cap', ' fa fa-gratipay' => ' fa fa-gratipay', ' fa fa-h-square' => ' fa fa-h-square', ' fa fa-hacker-news' => ' fa fa-hacker-news', ' fa fa-hand-o-down' => ' fa fa-hand-o-down', ' fa fa-hand-o-left' => ' fa fa-hand-o-left', ' fa fa-hand-o-right' => ' fa fa-hand-o-right', ' fa fa-hand-o-up' => ' fa fa-hand-o-up', ' fa fa-hdd-o' => ' fa fa-hdd-o', ' fa fa-header' => ' fa fa-header', ' fa fa-headphones' => ' fa fa-headphones', ' fa fa-heart' => ' fa fa-heart', ' fa fa-heart-o' => ' fa fa-heart-o', ' fa fa-heartbeat' => ' fa fa-heartbeat', ' fa fa-history' => ' fa fa-history', ' fa fa-home' => ' fa fa-home', ' fa fa-hospital-o' => ' fa fa-hospital-o', ' fa fa-html5' => ' fa fa-html5', ' fa fa-ils' => ' fa fa-ils', ' fa fa-inbox' => ' fa fa-inbox', ' fa fa-indent' => ' fa fa-indent', ' fa fa-info' => ' fa fa-info', ' fa fa-info-circle' => ' fa fa-info-circle', ' fa fa-inr' => ' fa fa-inr', ' fa fa-instagram' => ' fa fa-instagram', ' fa fa-ioxhost' => ' fa fa-ioxhost', ' fa fa-italic' => ' fa fa-italic', ' fa fa-joomla' => ' fa fa-joomla', ' fa fa-jpy' => ' fa fa-jpy', ' fa fa-jsfiddle' => ' fa fa-jsfiddle', ' fa fa-key' => ' fa fa-key', ' fa fa-keyboard-o' => ' fa fa-keyboard-o', ' fa fa-krw' => ' fa fa-krw', ' fa fa-language' => ' fa fa-language', ' fa fa-laptop' => ' fa fa-laptop', ' fa fa-lastfm' => ' fa fa-lastfm', ' fa fa-lastfm-square' => ' fa fa-lastfm-square', ' fa fa-leaf' => ' fa fa-leaf', ' fa fa-leanpub' => ' fa fa-leanpub', ' fa fa-lemon-o' => ' fa fa-lemon-o', ' fa fa-level-down' => ' fa fa-level-down', ' fa fa-level-up' => ' fa fa-level-up', ' fa fa-life-ring' => ' fa fa-life-ring', ' fa fa-lightbulb-o' => ' fa fa-lightbulb-o', ' fa fa-line-chart' => ' fa fa-line-chart', ' fa fa-link' => ' fa fa-link', ' fa fa-linkedin' => ' fa fa-linkedin', ' fa fa-linkedin-square' => ' fa fa-linkedin-square', ' fa fa-linux' => ' fa fa-linux', ' fa fa-list' => ' fa fa-list', ' fa fa-list-alt' => ' fa fa-list-alt', ' fa fa-list-ol' => ' fa fa-list-ol', ' fa fa-list-ul' => ' fa fa-list-ul', ' fa fa-location-arrow' => ' fa fa-location-arrow', ' fa fa-lock' => ' fa fa-lock', ' fa fa-long-arrow-down' => ' fa fa-long-arrow-down', ' fa fa-long-arrow-left' => ' fa fa-long-arrow-left', ' fa fa-long-arrow-right' => ' fa fa-long-arrow-right', ' fa fa-long-arrow-up' => ' fa fa-long-arrow-up', ' fa fa-magic' => ' fa fa-magic', ' fa fa-magnet' => ' fa fa-magnet', ' fa fa-male' => ' fa fa-male', ' fa fa-map-marker' => ' fa fa-map-marker', ' fa fa-mars' => ' fa fa-mars', ' fa fa-mars-double' => ' fa fa-mars-double', ' fa fa-mars-stroke' => ' fa fa-mars-stroke', ' fa fa-mars-stroke-h' => ' fa fa-mars-stroke-h', ' fa fa-mars-stroke-v' => ' fa fa-mars-stroke-v', ' fa fa-maxcdn' => ' fa fa-maxcdn', ' fa fa-meanpath' => ' fa fa-meanpath', ' fa fa-medium' => ' fa fa-medium', ' fa fa-medkit' => ' fa fa-medkit', ' fa fa-meh-o' => ' fa fa-meh-o', ' fa fa-mercury' => ' fa fa-mercury', ' fa fa-microphone' => ' fa fa-microphone', ' fa fa-microphone-slash' => ' fa fa-microphone-slash', ' fa fa-minus' => ' fa fa-minus', ' fa fa-minus-circle' => ' fa fa-minus-circle', ' fa fa-minus-square' => ' fa fa-minus-square', ' fa fa-minus-square-o' => ' fa fa-minus-square-o', ' fa fa-mobile' => ' fa fa-mobile', ' fa fa-money' => ' fa fa-money', ' fa fa-moon-o' => ' fa fa-moon-o', ' fa fa-motorcycle' => ' fa fa-motorcycle', ' fa fa-music' => ' fa fa-music', ' fa fa-neuter' => ' fa fa-neuter', ' fa fa-newspaper-o' => ' fa fa-newspaper-o', ' fa fa-openid' => ' fa fa-openid', ' fa fa-outdent' => ' fa fa-outdent', ' fa fa-pagelines' => ' fa fa-pagelines', ' fa fa-paint-brush' => ' fa fa-paint-brush', ' fa fa-paper-plane' => ' fa fa-paper-plane', ' fa fa-paper-plane-o' => ' fa fa-paper-plane-o', ' fa fa-paperclip' => ' fa fa-paperclip', ' fa fa-paragraph' => ' fa fa-paragraph', ' fa fa-pause' => ' fa fa-pause', ' fa fa-paw' => ' fa fa-paw', ' fa fa-paypal' => ' fa fa-paypal', ' fa fa-pencil' => ' fa fa-pencil', ' fa fa-pencil-square' => ' fa fa-pencil-square', ' fa fa-pencil-square-o' => ' fa fa-pencil-square-o', ' fa fa-phone' => ' fa fa-phone', ' fa fa-phone-square' => ' fa fa-phone-square', ' fa fa-picture-o' => ' fa fa-picture-o', ' fa fa-pie-chart' => ' fa fa-pie-chart', ' fa fa-pied-piper' => ' fa fa-pied-piper', ' fa fa-pied-piper-alt' => ' fa fa-pied-piper-alt', ' fa fa-pinterest' => ' fa fa-pinterest', ' fa fa-pinterest-p' => ' fa fa-pinterest-p', ' fa fa-pinterest-square' => ' fa fa-pinterest-square', ' fa fa-plane' => ' fa fa-plane', ' fa fa-play' => ' fa fa-play', ' fa fa-play-circle' => ' fa fa-play-circle', ' fa fa-play-circle-o' => ' fa fa-play-circle-o', ' fa fa-plug' => ' fa fa-plug', ' fa fa-plus' => ' fa fa-plus', ' fa fa-plus-circle' => ' fa fa-plus-circle', ' fa fa-plus-square' => ' fa fa-plus-square', ' fa fa-plus-square-o' => ' fa fa-plus-square-o', ' fa fa-power-off' => ' fa fa-power-off', ' fa fa-print' => ' fa fa-print', ' fa fa-puzzle-piece' => ' fa fa-puzzle-piece', ' fa fa-qq' => ' fa fa-qq', ' fa fa-qrcode' => ' fa fa-qrcode', ' fa fa-question' => ' fa fa-question', ' fa fa-question-circle' => ' fa fa-question-circle', ' fa fa-quote-left' => ' fa fa-quote-left', ' fa fa-quote-right' => ' fa fa-quote-right', ' fa fa-random' => ' fa fa-random', ' fa fa-rebel' => ' fa fa-rebel', ' fa fa-recycle' => ' fa fa-recycle', ' fa fa-reddit' => ' fa fa-reddit', ' fa fa-reddit-square' => ' fa fa-reddit-square', ' fa fa-refresh' => ' fa fa-refresh', ' fa fa-renren' => ' fa fa-renren', ' fa fa-repeat' => ' fa fa-repeat', ' fa fa-reply' => ' fa fa-reply', ' fa fa-reply-all' => ' fa fa-reply-all', ' fa fa-retweet' => ' fa fa-retweet', ' fa fa-road' => ' fa fa-road', ' fa fa-rocket' => ' fa fa-rocket', ' fa fa-rss' => ' fa fa-rss', ' fa fa-rss-square' => ' fa fa-rss-square', ' fa fa-rub' => ' fa fa-rub', ' fa fa-scissors' => ' fa fa-scissors', ' fa fa-search' => ' fa fa-search', ' fa fa-search-minus' => ' fa fa-search-minus', ' fa fa-search-plus' => ' fa fa-search-plus', ' fa fa-sellsy' => ' fa fa-sellsy', ' fa fa-server' => ' fa fa-server', ' fa fa-share' => ' fa fa-share', ' fa fa-share-alt' => ' fa fa-share-alt', ' fa fa-share-alt-square' => ' fa fa-share-alt-square', ' fa fa-share-square' => ' fa fa-share-square', ' fa fa-share-square-o' => ' fa fa-share-square-o', ' fa fa-shield' => ' fa fa-shield', ' fa fa-ship' => ' fa fa-ship', ' fa fa-shirtsinbulk' => ' fa fa-shirtsinbulk', ' fa fa-shopping-cart' => ' fa fa-shopping-cart', ' fa fa-sign-in' => ' fa fa-sign-in', ' fa fa-sign-out' => ' fa fa-sign-out', ' fa fa-signal' => ' fa fa-signal', ' fa fa-simplybuilt' => ' fa fa-simplybuilt', ' fa fa-sitemap' => ' fa fa-sitemap', ' fa fa-skyatlas' => ' fa fa-skyatlas', ' fa fa-skype' => ' fa fa-skype', ' fa fa-slack' => ' fa fa-slack', ' fa fa-sliders' => ' fa fa-sliders', ' fa fa-slideshare' => ' fa fa-slideshare', ' fa fa-smile-o' => ' fa fa-smile-o', ' fa fa-sort' => ' fa fa-sort', ' fa fa-sort-alpha-asc' => ' fa fa-sort-alpha-asc', ' fa fa-sort-alpha-desc' => ' fa fa-sort-alpha-desc', ' fa fa-sort-amount-asc' => ' fa fa-sort-amount-asc', ' fa fa-sort-amount-desc' => ' fa fa-sort-amount-desc', ' fa fa-sort-asc' => ' fa fa-sort-asc', ' fa fa-sort-desc' => ' fa fa-sort-desc', ' fa fa-sort-numeric-asc' => ' fa fa-sort-numeric-asc', ' fa fa-sort-numeric-desc' => ' fa fa-sort-numeric-desc', ' fa fa-soundcloud' => ' fa fa-soundcloud', ' fa fa-space-shuttle' => ' fa fa-space-shuttle', ' fa fa-spinner' => ' fa fa-spinner', ' fa fa-spoon' => ' fa fa-spoon', ' fa fa-spotify' => ' fa fa-spotify', ' fa fa-square' => ' fa fa-square', ' fa fa-square-o' => ' fa fa-square-o', ' fa fa-stack-exchange' => ' fa fa-stack-exchange', ' fa fa-stack-overflow' => ' fa fa-stack-overflow', ' fa fa-star' => ' fa fa-star', ' fa fa-star-half' => ' fa fa-star-half', ' fa fa-star-half-o' => ' fa fa-star-half-o', ' fa fa-star-o' => ' fa fa-star-o', ' fa fa-steam' => ' fa fa-steam', ' fa fa-steam-square' => ' fa fa-steam-square', ' fa fa-step-backward' => ' fa fa-step-backward', ' fa fa-step-forward' => ' fa fa-step-forward', ' fa fa-stethoscope' => ' fa fa-stethoscope', ' fa fa-stop' => ' fa fa-stop', ' fa fa-street-view' => ' fa fa-street-view', ' fa fa-strikethrough' => ' fa fa-strikethrough', ' fa fa-stumbleupon' => ' fa fa-stumbleupon', ' fa fa-stumbleupon-circle' => ' fa fa-stumbleupon-circle', ' fa fa-subscript' => ' fa fa-subscript', ' fa fa-subway' => ' fa fa-subway', ' fa fa-suitcase' => ' fa fa-suitcase', ' fa fa-sun-o' => ' fa fa-sun-o', ' fa fa-superscript' => ' fa fa-superscript', ' fa fa-table' => ' fa fa-table', ' fa fa-tablet' => ' fa fa-tablet', ' fa fa-tachometer' => ' fa fa-tachometer', ' fa fa-tag' => ' fa fa-tag', ' fa fa-tags' => ' fa fa-tags', ' fa fa-tasks' => ' fa fa-tasks', ' fa fa-taxi' => ' fa fa-taxi', ' fa fa-tencent-weibo' => ' fa fa-tencent-weibo', ' fa fa-terminal' => ' fa fa-terminal', ' fa fa-text-height' => ' fa fa-text-height', ' fa fa-text-width' => ' fa fa-text-width', ' fa fa-th' => ' fa fa-th', ' fa fa-th-large' => ' fa fa-th-large', ' fa fa-th-list' => ' fa fa-th-list', ' fa fa-thumb-tack' => ' fa fa-thumb-tack', ' fa fa-thumbs-down' => ' fa fa-thumbs-down', ' fa fa-thumbs-o-down' => ' fa fa-thumbs-o-down', ' fa fa-thumbs-o-up' => ' fa fa-thumbs-o-up', ' fa fa-thumbs-up' => ' fa fa-thumbs-up', ' fa fa-ticket' => ' fa fa-ticket', ' fa fa-times' => ' fa fa-times', ' fa fa-times-circle' => ' fa fa-times-circle', ' fa fa-times-circle-o' => ' fa fa-times-circle-o', ' fa fa-tint' => ' fa fa-tint', ' fa fa-toggle-off' => ' fa fa-toggle-off', ' fa fa-toggle-on' => ' fa fa-toggle-on', ' fa fa-train' => ' fa fa-train', ' fa fa-transgender' => ' fa fa-transgender', ' fa fa-transgender-alt' => ' fa fa-transgender-alt', ' fa fa-trash' => ' fa fa-trash', ' fa fa-trash-o' => ' fa fa-trash-o', ' fa fa-tree' => ' fa fa-tree', ' fa fa-trello' => ' fa fa-trello', ' fa fa-trophy' => ' fa fa-trophy', ' fa fa-truck' => ' fa fa-truck', ' fa fa-try' => ' fa fa-try', ' fa fa-tty' => ' fa fa-tty', ' fa fa-tumblr' => ' fa fa-tumblr', ' fa fa-tumblr-square' => ' fa fa-tumblr-square', ' fa fa-twitch' => ' fa fa-twitch', ' fa fa-twitter' => ' fa fa-twitter', ' fa fa-twitter-square' => ' fa fa-twitter-square', ' fa fa-umbrella' => ' fa fa-umbrella', ' fa fa-underline' => ' fa fa-underline', ' fa fa-undo' => ' fa fa-undo', ' fa fa-university' => ' fa fa-university', ' fa fa-unlock' => ' fa fa-unlock', ' fa fa-unlock-alt' => ' fa fa-unlock-alt', ' fa fa-upload' => ' fa fa-upload', ' fa fa-usd' => ' fa fa-usd', ' fa fa-user' => ' fa fa-user', ' fa fa-user-md' => ' fa fa-user-md', ' fa fa-user-plus' => ' fa fa-user-plus', ' fa fa-user-secret' => ' fa fa-user-secret', ' fa fa-user-times' => ' fa fa-user-times', ' fa fa-users' => ' fa fa-users', ' fa fa-venus' => ' fa fa-venus', ' fa fa-venus-double' => ' fa fa-venus-double', ' fa fa-venus-mars' => ' fa fa-venus-mars', ' fa fa-viacoin' => ' fa fa-viacoin', ' fa fa-video-camera' => ' fa fa-video-camera', ' fa fa-vimeo-square' => ' fa fa-vimeo-square', ' fa fa-vine' => ' fa fa-vine', ' fa fa-vk' => ' fa fa-vk', ' fa fa-volume-down' => ' fa fa-volume-down', ' fa fa-volume-off' => ' fa fa-volume-off', ' fa fa-volume-up' => ' fa fa-volume-up', ' fa fa-weibo' => ' fa fa-weibo', ' fa fa-weixin' => ' fa fa-weixin', ' fa fa-whatsapp' => ' fa fa-whatsapp', ' fa fa-wheelchair' => ' fa fa-wheelchair', ' fa fa-wifi' => ' fa fa-wifi', ' fa fa-windows' => ' fa fa-windows', ' fa fa-wordpress' => ' fa fa-wordpress', ' fa fa-wrench' => ' fa fa-wrench', ' fa fa-xing' => ' fa fa-xing', ' fa fa-xing-square' => ' fa fa-xing-square', ' fa fa-yahoo' => ' fa fa-yahoo', ' fa fa-yelp' => ' fa fa-yelp', ' fa fa-youtube' => ' fa fa-youtube', ' fa fa-youtube-play' => ' fa fa-youtube-play', ' fa fa-youtube-square' => ' fa fa-youtube-square',);
		return $icons;	
	}
}

/**
 * Custom Comment Markup for Pivot
 * 
 * @since 1.0.0
 * @author tommusrhodus
 */
if(!( function_exists( 'ebor_custom_comment' ) )){
	function ebor_custom_comment( $comment, $args, $depth ) { 
		$GLOBALS['comment'] = $comment; 
	?>
		
		<li <?php comment_class(); ?> id="comment-<?php comment_ID() ?>">
			<div class="avatar">
				<?php echo get_avatar( $comment->comment_author_email, 75 ); ?>
			</div>
			<div class="comment">
				<?php printf( '<span class="uppercase author">%s, %s</span>', get_comment_author_link(), get_comment_date() ); ?>
				<?php comment_reply_link( array_merge( $args, array( 'depth' => $depth, 'max_depth' => $args['max_depth'] )) ); ?>
				<?php echo wpautop( get_comment_text() ); ?>
				<?php if ($comment->comment_approved == '0') : ?>
				<p><em><?php esc_html_e( 'Your comment is awaiting moderation.', 'launchkit' ) ?></em></p>
				<?php endif; ?>	
			</div>
	
	<?php }
}