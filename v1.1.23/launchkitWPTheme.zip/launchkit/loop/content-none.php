<p class="lead"><?php esc_html_e( 'Sorry, no results were found, search again?', 'launchkit' ); ?></p>
<?php get_search_form(); ?>