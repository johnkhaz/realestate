<aside class="col-md-3 hidden-sm">
	<?php dynamic_sidebar( 'primary' ); ?>
</aside>